# mgs-2023 logic
