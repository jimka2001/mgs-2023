def hello(name):
    print("hello " + name)
