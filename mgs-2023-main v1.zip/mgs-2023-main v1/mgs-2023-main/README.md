# mgs-2023

Prepend ![gitpod](doc/img/prepend-gitpod.png) 

```
http://gitpod.io/#https://github.com/jimka2001/mgs-2023
```
[Open gitpod](http://gitpod.io/#https://github.com/jimka2001/mgs-2023)

